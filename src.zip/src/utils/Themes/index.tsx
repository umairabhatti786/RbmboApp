export const theme={

    colors:{
        primary:"#984A8B",
        black:"#000000",
        text_black:"#212121",
        dark_gray:"#646464",
        gray:"#4D4D4D",
        white:"#ffff",
        background:"#FEFEFE",
        alert:"#F55656"
        
    }






}