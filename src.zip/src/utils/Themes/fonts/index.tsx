export const fonts = {
  Poppins_Black: 'Poppins-Black',
  Poppins_Medium: 'Poppins-Medium',
  Poppins_Light: 'Poppins_Light',
  Poppins_SemiBold: 'Poppins-SemiBold',
  Poppins_Regular: 'Poppins-Regular',
  Poppins_Bold: 'Poppins-Bold',
  Poppins_ExtraBold: 'Poppins-ExtraBold',

  DMSans_Regular: 'DMSans-Regular',
  DMSans_Medium: 'DMSans-Medium',
  DMSans_SemiBold: 'DMSans-SemiBold',
  DMSans_Bold: 'DMSans-Bold',
  DMSans_ExtraBold: 'DMSans-ExtraBold',
  DMSans_Light: 'DMSans-Light',
};
