import { Platform, StyleSheet } from "react-native";


export const appStyles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
  },
  rowjustify: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

//   Container: {
//     flex: 1,
//     backgroundColor: t.colors.background,
//     paddingHorizontal: sizeHelper.calWp(30),
//     paddingTop: sizeHelper.calHp(Platform.OS=="ios"?10 :30),
//     gap: sizeHelper.calWp(30),
//   },
//   backBtn: {
//     width: sizeHelper.calWp(70),
//     height: sizeHelper.calWp(70),
//     alignItems: "center",
//     justifyContent: "center",
//     backgroundColor: theme.colors.white,
//     borderRadius: sizeHelper.calWp(30),
//   },

 
});
