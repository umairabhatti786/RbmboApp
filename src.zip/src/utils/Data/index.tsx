import { images } from "../../assets/images";

export   const productData = [
    {
      img: images.product1,
      name: "White Sneaker",
      discount: "€34",
      price: "MAD 450",
      date: "On 08/02/2025 at 23:11",
      location: "2972 Westheimer Rd. Santa Ana,",
      negotiable: true,
    },
    {
      img: images.product,
      name: "White Sneaker",
      discount: "€34",
      price: "MAD 450",
      date: "On 08/02/2025 at 23:11",
      location: "2972 Westheimer Rd. Santa Ana,",
    },
  ];