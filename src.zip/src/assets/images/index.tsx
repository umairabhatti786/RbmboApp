export const images = {
  product: require("../images/product.png"),
  profile_img: require("../images/profile_img.png"),
  product1: require("../images/product1.png"),
};
