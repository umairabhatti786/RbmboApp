import React, { useEffect, useState } from "react";
import { View, StyleSheet } from "react-native";
import ScreenLayout from "../../../components/ScreenLayout";

const BoxScreen = ({ navigation }: any) => {
  return <ScreenLayout>
    
  </ScreenLayout>;
};

export default BoxScreen;

const styles = StyleSheet.create({});
