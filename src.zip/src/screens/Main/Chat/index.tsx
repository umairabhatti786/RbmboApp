import React, { useEffect, useState } from "react";
import { StyleSheet } from "react-native";
import sizeHelper from "../../../utils/Helpers";
import ScreenLayout from "../../../components/ScreenLayout";

const ChatScreen = ({ navigation }: any) => {
  return <ScreenLayout>
    
  </ScreenLayout>;
};

export default ChatScreen;

const styles = StyleSheet.create({});
