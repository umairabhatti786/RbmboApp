import React, { useEffect, useState } from "react";
import { StyleSheet } from "react-native";
import ScreenLayout from "../../../components/ScreenLayout";

const LikedScreen = ({ navigation }: any) => {
  return <ScreenLayout>
    
  </ScreenLayout>;
};

export default LikedScreen;

const styles = StyleSheet.create({});
