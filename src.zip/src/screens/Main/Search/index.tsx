import React, { useEffect, useState } from "react";
import { StyleSheet } from "react-native";
import sizeHelper from "../../../utils/Helpers";
import ScreenLayout from "../../../components/ScreenLayout";

const SearchScreen = ({ navigation }: any) => {
  return <ScreenLayout>
    
  </ScreenLayout>;
};

export default SearchScreen;

const styles = StyleSheet.create({});
